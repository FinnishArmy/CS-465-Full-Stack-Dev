<h1 align="center"> CS-465 </h1>
<p align="center"> Full Stack Development </p>
<p align="center"> Design and develop a full stack application through the utilization of programming language frameworks </p>

<p align="center">
<img alt="image" src="snhu.png" width="150" height="150" />
</p>

## Table of Contents
- [Course Description](#-course-description-)

## <h1 align="center"> Course Description </h1>
Students will design and develop a full stack application through the utilization of programming language frameworks. In creating a full stack application, students will also be responsible for developing a database as well as the code that interfaces their application to the database. This is the first course in a two-course sequence.

## <h1 align="center"> Module One </h1>
Produce a working shell of the customer-facing web application that is rendered in the browser.

See documentation [here]
